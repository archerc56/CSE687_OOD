#pragma once
#ifdef TESTBADFUNCTIONCALL_EXPORTS
#define TESTBADFUNCTIONCALL_API __declspec(dllexport)
#else
#define TESTBADFUNCTIONCALL_API __declspec(dllimport)
#endif

extern "C" TESTBADFUNCTIONCALL_API bool TestBadFunctionCall();