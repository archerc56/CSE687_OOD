#include "pch.h"
#include "framework.h"
#include "TestBadFunctionCall.h"
#include <iostream>
#include <functional>


TESTBADFUNCTIONCALL_API bool TestBadFunctionCall()
{
	std::bad_function_call e;
	std::cout << "TestBadFunctionCall \n";
	std::function<int()> TestBadFunction = nullptr;
	TestBadFunction();
	throw e;
	return true;
}
