#pragma once
#ifdef TESTADD_EXPORTS
#define TESTADD_API __declspec(dllexport)
#else
#define TESTADD_API __declspec(dllimport)
#endif

extern "C" TESTADD_API void TestAdd();
