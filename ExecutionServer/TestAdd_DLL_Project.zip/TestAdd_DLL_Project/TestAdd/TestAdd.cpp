#include "pch.h"
#include "framework.h"
#include "TestAdd.h"
#include <iostream>

TESTADD_API void TestAdd()
{
	std::cout << "TestAdd \n";
	int i, j;
	i = 1;
	j = 2;
	j = j + i;
}
