#pragma once
#ifdef TESTBADALLOC_EXPORTS
#define TESTBADALLOC_API __declspec(dllexport)
#else
#define TESTBADALLOC_API __declspec(dllimport)
#endif

extern "C" TESTBADALLOC_API bool TestBadAlloc();