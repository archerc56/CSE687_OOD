#include "pch.h"
#include "framework.h"
#include "TestBadAlloc.h"
#include <new>
#include <iostream>

TESTBADALLOC_API bool TestBadAlloc()
{
	std::bad_alloc x;
	std::cout << "TestBadAlloc \n";
	while (true)
	{
		new int[100000000ul];
	}
	throw x;
	return true;
}
