#pragma once
#ifdef TESTALLOCATE_EXPORTS
#define TESTALLOCATE_API __declspec(dllexport)
#else
#define TESTALLOCATE_API __declspec(dllimport)
#endif

extern "C" TESTALLOCATE_API void TestAllocate();