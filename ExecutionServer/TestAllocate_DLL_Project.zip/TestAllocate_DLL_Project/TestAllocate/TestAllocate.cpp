#include "pch.h"
#include "framework.h"
#include "TestAllocate.h"
#include <iostream>

TESTALLOCATE_API void TestAllocate()
{
	std::cout << "TestAllocate \n";
	int* foo;
	foo = new int[10];
}
