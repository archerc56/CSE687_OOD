#pragma once
#ifdef TESTBADWEAKPTR_EXPORTS
#define TESTBADWEAKPTR_API __declspec(dllexport)
#else
#define TESTBADWEAKPTR_API __declspec(dllimport)
#endif

extern "C" TESTBADWEAKPTR_API bool TestBadWeakPtr();